<?php

$kuotaList = [
    [
        "kuota_name" => "PAKET INTERNET 1 HARI",
        "kuota_size" => "2.5 GB",
        "kuota_price" => "10.000"
    ],
    [
        "kuota_name" => "PAKET INTERNET 7 HARI",
        "kuota_size" => "6 GB",
        "kuota_price" => "25.000"
    ],
    [
        "kuota_name" => "PAKET INTERNET 7 HARI",
        "kuota_size" => "3.5 GB",
        "kuota_price" => "15.000"
    ],
    [
        "kuota_name" => "PAKET INTERNET 30 HARI",
        "kuota_size" => "8 GB",
        "kuota_price" => "40.000"
    ],
    [
        "kuota_name" => "PAKET INTERNET 30 HARI",
        "kuota_size" => "10 GB",
        "kuota_price" => "50.000"
    ],
    [
        "kuota_name" => "PAKET INTERNET UNLIMITED YOUTUBE, WA, IG 30 HARI",
        "kuota_size" => "UNLIMITED",
        "kuota_price" => "100.000"
    ],
    [
        "kuota_name" => "PAKET INTERNET 15 HARI",
        "kuota_size" => "7.5 GB",
        "kuota_price" => "30.000"
    ],
    [
        "kuota_name" => "PAKET INTERNET 30 HARI",
        "kuota_size" => "8 GB",
        "kuota_price" => "40.000"
    ],
    [
        "kuota_name" => "PAKET INTERNET 7 HARI",
        "kuota_size" => "6 GB",
        "kuota_price" => "25.000"
    ],
    [
        "kuota_name" => "PAKET INTERNET 7 HARI",
        "kuota_size" => "5 GB",
        "kuota_price" => "20.000"
    ],
    [
        "kuota_name" => "PAKET INTERNET 1 HARI",
        "kuota_size" => "3.5 GB",
        "kuota_price" => "15.000"
    ],
    [
        "kuota_name" => "PAKET INTERNET 1 HARI",
        "kuota_size" => "3.5 GB",
        "kuota_price" => "15.000"
    ],  
];
?>